# WingdingsTranslator
A little wingdings to text and text to wingdings translator!

This is a "Wingdings To Text" or "Text To Wingdings" translator!
It took like 4 hours to make so this is like nothing!
It was made in python, source code available.
Using the .bat file will run the code with the terminal not showing!
If you find any errors or symbols/characters that aren't in there then report the issue and i will fix it!
And i hope you like it!